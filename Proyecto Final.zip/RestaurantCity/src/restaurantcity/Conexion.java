package restaurantcity;

public class Conexion
{
    
}
